import * as React from 'react';
import { Text, View, StyleSheet, Button, TouchableOpacity} from 'react-native';
import {Input, NativeBaseProvider, Icon, Box, Image, AspectRatio } from 'native-base';
import Constants from 'expo-constants';
import { FontAwesome
 } from '@expo/vector-icons';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { Card } from 'react-native-paper';


function HomeScreen() {
  return (
    
    <View style={styles.container}>
      <Text style={styles.title}>
          LP GAS
      </Text>
      <Text style={styles.subTitle}>
        Searching For Gas?
      </Text>
      <View style={styles.category}>
        <Text style={styles.categoryOne}>Litro Gas</Text>
        <View>
          <TouchableOpacity style={{
            backgroundColor:'#E3E3E3',
            paddingHorizontal:20,
            paddingVertical:5,
            marginBottom:10,
            alignItems:'center'
            }}>
              <Text style={styles.weightText}>5 KG</Text>
          </TouchableOpacity>

          <TouchableOpacity style={{
            backgroundColor:'#E3E3E3',
            paddingHorizontal:20,
            paddingVertical:5,
            marginBottom:10,
            alignItems:'center'
            }}>
              <Text style={styles.weightText}>12.5 KG</Text>
          </TouchableOpacity>

          <TouchableOpacity style={{
            backgroundColor:'#E3E3E3',
            paddingHorizontal:20,
            paddingVertical:5,
            marginBottom:10,
            alignItems:'center'
            }}>
              <Text style={styles.weightText}>37.5 KG</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.category}>
        <Text style={styles.categoryOne}>Laugh Gas</Text>
        <View>
          <TouchableOpacity style={{
            backgroundColor:'#E3E3E3',
            paddingHorizontal:20,
            paddingVertical:5,
            marginBottom:10,
            alignItems:'center'
            }}>
              <Text style={styles.weightText}>5 KG</Text>
          </TouchableOpacity>

          <TouchableOpacity style={{
            backgroundColor:'#E3E3E3',
            paddingHorizontal:20,
            paddingVertical:5,
            marginBottom:10,
            alignItems:'center'
            }}>
              <Text style={styles.weightText}>12.5 KG</Text>
          </TouchableOpacity>

          <TouchableOpacity style={{
            backgroundColor:'#E3E3E3',
            paddingHorizontal:20,
            paddingVertical:5,
            marginBottom:30,
            alignItems:'center',
            }}>
              <Text style={styles.weightText}>37.5 KG</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.buttonStyle}>
        <View style={styles.emailInput}>
            <Input
                varient ="outline"
                placeholder="search For location"/>
        </View>
      </View>
      <Button title="Search"/>
    </View>
  );
}

export default () => {
    return (
        <NativeBaseProvider>
            <HomeScreen/>
        </NativeBaseProvider>
    )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#fff',
    padding: 20,
  },

  title: {
    margin: 24,
    top:0,
    fontSize: 50,
    fontWeight: 'bold',
    textAlign: 'center',
    color:'#EE1160'
  },

  subTitle:{
    fontSize:25,
  },

  category:{
    marginTop:30,
    flexDirection:'row',
    justifyContent:"space-between"
  },

  categoryOne:{
    marginRight:40,
    fontSize:20,
  },

  weightText:{
    fontSize:20,
    color:'#000'
  },

  buttonStyle: {
    marginLeft: 15,
    marginRight: 15,
    marginBottom:40
  },
  
  emailInput:{
    marginRight:5,
  },
});

