import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import React from 'react';
import { Input, NativeBaseProvider, Button, Icon, Box, Image, AspectRatio, Alert } from 'native-base';
import { FontAwesome
 } from '@expo/vector-icons';
import { NavigationContainer, useNavigation } from '@react-navigation/native';


function Login() {
    const navigation = useNavigation();
    const Login =() =>navigation.navigate('HomeScreen'); 
    
    return (
        <View style={styles.container}>

            

            <View style={styles.Middle}>
                <Text style={styles.LoginText}>Log in</Text>
            </View>
            

            {/* username or email iput field */}
            <View style={styles.buttonStyle}>
                <View style={styles.emailInput}>
                    <Input
                        InputLeftElement={
                            <Icon
                                as={<FontAwesome name="user-secret" />}
                                size="sm"
                                m={2}
                                _light={{
                                    color: 'black',
                                }}
                                _dark={{
                                    color: 'gray.300',
                                }}
                            />
                        }
                        varient ="outline"
                        placeholder="Username or Emial"
                        _light={{
                            placeholderTextColor: "blueGray.400",
                        }}
                        _dark={{
                            placeholderTextColor: "blueGray.50",
                        }}
                    
                    />
                </View>
            </View>
            {/* password input  */}
            <View style={styles.buttonStyleX}>
                <View style={styles.emailInput}>
                    <Input
                        InputLeftElement={
                            <Icon
                                as={<FontAwesome name="key" />}
                                size="sm"
                                m={2}
                                _light={{
                                    color: 'black',
                                }}
                                _dark={{
                                    color: 'gray.300',
                                }}
                            />
                        }
                        varient="outline"
                        secureTextEntry={true}
                        placeholder="password"
                        _light={{
                            placeholderTextColor: "blueGray.400",
                        }}
                        _dark={{
                            placeholderTextColor: "blueGray.50",
                        }}
                    
                    />
                </View>
            </View>

            <View style={styles.text3}>
                <Text >Forgot you're </Text>
                <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
                    <Text style={styles.signupText}>Password</Text>
                </TouchableOpacity>
            </View>

            {/* button */}
            <View style={styles.buttonStyle}>
                <Button style={styles.buttonDesign} onPress={Login}>
                        Log in
                </Button>
            </View>
            
            <View style={styles.text2}>
                <Text >Don't have an account?  </Text>
                <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
                    <Text style={styles.signupText}>Sign up</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}
export default () => {
    return (
        <NativeBaseProvider>
            <Login/>
        </NativeBaseProvider>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    LoginText: {
        marginTop: 100,
        fontSize: 30,
        color:'#EE1160',
        fontWeight: 'bold',
    },
    Middle: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    text2: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop:210,
    },

    text3: {
        flexDirection: 'row',
        justifyContent: 'center',
        paddingTop:10,
    },

    signupText: {
        fontweight: 'bold',
        color:'#EE1160',  
    },
    emailInput:{
        marginTop:10,
        marginRight:5,
    },
    buttonStyle: {
        marginTop: 30,
        marginLeft: 15,
        marginRight: 15
    },
    buttonStyleX: {
        marginTop: 12,
        marginLeft: 15,
        marginRight: 15,
    },
    buttonDesign:{
        backgroundColor:'#EE1160',
        
    }
})
