import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import React from 'react';
import { Input, NativeBaseProvider, Button, Icon, Box, Image, AspectRatio } from 'native-base';
import { FontAwesome, MaterialCommunityIcons} from '@expo/vector-icons';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
//Signup



function Signup() {
    const navigation = useNavigation();
    return (
        <View style={styles.container}>

            

            <View style={styles.Middle}>
                <Text style={styles.signupText}>Sign up</Text>
            </View>
           

            {/* username iput field */}
            <View style={styles.buttonStyle}>
                <View style={styles.emailInput}>
                    <Input
                        InputLeftElement={
                            <Icon
                                as={<FontAwesome name="user-secret" />}
                                size="sm"
                                m={2}
                                _light={{
                                    color: 'black',
                                }}
                                _dark={{
                                    color: 'gray.300',
                                }}
                            />
                        }
                        varient ="outline"
                        placeholder="Username or Email"
                        _light={{
                            placeholderTextColor: "blueGray.400",
                        }}
                        _dark={{
                            placeholderTextColor: "blueGray.50",
                        }}
                    
                    />
                </View>
            </View>

            {/* Email iput field */}
            <View style={styles.buttonStyle}>
                <View>
                    <Input
                        InputLeftElement={
                            <Icon
                                as={<MaterialCommunityIcons name="email" />}
                                size="sm"
                                m={2}
                                _light={{
                                    color: 'black',
                                }}
                                _dark={{
                                    color: 'gray.300',
                                }}
                            />
                        }
                        varient ="outline"
                        placeholder="Emial"
                        _light={{
                            placeholderTextColor: "blueGray.400",
                        }}
                        _dark={{
                            placeholderTextColor: "blueGray.50",
                        }}
                    
                    />
                </View>
            </View>

            {/* password input  */}
            <View style={styles.buttonStyleX}>
                <View style={styles.emailInput}>
                    <Input
                        InputLeftElement={
                            <Icon
                                as={<FontAwesome name="key" />}
                                size="sm"
                                m={2}
                                _light={{
                                    color: 'black',
                                }}
                                _dark={{
                                    color: 'gray.300',
                                }}
                            />
                        }
                        varient="outline"
                        secureTextEntry={true}
                        placeholder="password"
                        _light={{
                            placeholderTextColor: "blueGray.400",
                        }}
                        _dark={{
                            placeholderTextColor: "blueGray.50",
                        }}
                    
                    />
                </View>
            </View>

            {/* button */}
            <View style={styles.buttonStyle}>
                <Button style={styles.buttonDesign}>
                    Sign up
                </Button>
            </View>

             <View style={styles.text2}>
                <Text >Already have an account?  </Text>
                <TouchableOpacity onPress={() => navigation.navigate('login')}>
                    <Text style={styles.loginText}>Log in</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}
export default () => {
    return (
        <NativeBaseProvider>
            <Signup/>
        </NativeBaseProvider>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    signupText: {
        marginTop: 100,
        fontSize: 30,
        fontWeight: 'bold',
        color:'#EE1160',
    },
    Middle: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    text2: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop:170,
    },
    loginText: {
        fontweight: 'bold',
        color:'#EE1160'
         
    },
    emailInput:{
        marginTop:10,
        marginRight:5,
    },
    buttonStyle: {
        marginTop: 30,
        marginLeft: 15,
        marginRight: 15
    },
    buttonStyleX: {
        marginTop: 12,
        marginLeft: 15,
        marginRight: 15,
    },


    buttonDesign:{
        backgroundColor:'#EE1160',
    }
})
