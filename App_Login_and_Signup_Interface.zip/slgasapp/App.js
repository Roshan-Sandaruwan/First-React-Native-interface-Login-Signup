import React from 'react';
import Login from './login';
import Signup from './signup';
import HomeScreen from './screens/HomeScreen';
import { Navigator,NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View } from 'native-base';
// import { View, Text } from 'react-native'

const Stack = createNativeStackNavigator ();

function App() { 
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
           
      <Stack.Screen name="login" component={Login}/>
      <Stack.Screen name="Signup" component={Signup}/>
      <Stack.Screen name = "HomeScreen" component={HomeScreen}/> 
      
     
    </Stack.Navigator>
  )
}

export default () => {
  return (
    <NavigationContainer>
      <App/>
    </NavigationContainer>
  )
}

